---------------------------------------------------------------------------
-- FlightDash V4 Widget 
-- EdgeTX 2.11+
---------------------------------------------------------------------------

--Standard EdgeTx Colours
--BLACK
--WHITE
--GREEN
--DARKGREEN
--YELLOW
--RED
--DARKRED
--GREY
--DARKGREY
--BLUE
--ORANGE
--DARKBROWN

local name = "fltDash4"

local PURPLE = lcd.RGB(149, 66, 245)
local BROWN = lcd.RGB(79, 54, 39)
local PINK = lcd.RGB(206, 126, 252)
local CYAN = lcd.RGB(58, 242, 242)
local LIGHTBLUE = lcd.RGB(25, 175, 255)

local tlmColor = ORANGE

---------------------------------------------------------------------------
-- OPTIONS
---------------------------------------------------------------------------

local options = {
  { "Arm",       SWITCH, 0 },
  { "Motor",     SWITCH, 0 },
  { "Rx Signal", SOURCE, 0 },
  { "Rx Qty",    SOURCE, 0 },
  { "Rpm",       SOURCE, 0 },
  { "Rx Batt",   SOURCE, 0 },
  { "Curr",      SOURCE, 0 },
  { "Tesc",      SOURCE, 0 },
  { "Cells",      SOURCE, 0 },
  { "Vbec",      SOURCE, 0 },
}

---------------------------------------------------------------------------
-- IMAGE HELPERS
---------------------------------------------------------------------------
-- Check image name has .png and if it doesn't add it
local bm = nil 

local function pngFilename(imgName)
  if not imgName or imgName == "" then return nil end

  if not string.match(imgName, "%.png$") then
    imgName = imgName .. ".png"
  end

  return imgName
end


local function loadImage(imgName)
  bm = nil

  if not imgName or imgName == "" then return false end

  local filename = pngFilename(imgName)
  local path = "/IMAGES/" .. filename

  local ok, img = pcall(Bitmap.open, path)

  if ok and img then
    bm = img
    return true
  end

  return false
end

---------------------------------------------------------------------------
-- CREATE
---------------------------------------------------------------------------

--local function create(zone, opts)
  --return { zone = zone, options = opts or {} }
--end

local function create(zone, opts)
  local w = { zone = zone, options = opts or {} }

  local modelName = model.getInfo().name
  loadImage(modelName)

  return w
end

---------------------------------------------------------------------------
-- UPDATE
---------------------------------------------------------------------------
local function update(widget, opts)
  widget.options = opts
end

---------------------------------------------------------------------------
-- SOURCE LABEL FUNCTION
---------------------------------------------------------------------------
local function sourceLabel(src, fallback)
  if src ~= 0 then
    local info = getSourceInfo(src)
    if info and info.name then
      return info.name
    end
  end
  return fallback
end

---------------------------------------------------------------------------
-- BATTERY ICON
---------------------------------------------------------------------------
local function drawBatteryIcon(x, y, w, h, percent, color)
  lcd.drawRectangle(x, y, w, h, WHITE)
  lcd.drawFilledRectangle(x + w, y + h / 3, 4, h / 3, WHITE)
  lcd.drawFilledRectangle(x + 1, y + 1, (w - 2) * percent, h - 2, color)
end 
---------------------------------------------------------------------------
-- REFRESH
---------------------------------------------------------------------------

local function refresh(widget)
  local z   = widget.zone
  local opt = widget.options

  lcd.drawFilledRectangle(z.x, z.y, z.w, z.h, BLACK)
  lcd.drawFilledRectangle(z.x, z.y, z.w, 45, GREY)
  
  ---------------------------------------------------------------------------
  -- MOTOR / ARM / FM / MODEL NAME
  ---------------------------------------------------------------------------
  local rssVal  = (opt["Rx Signal"] ~= 0 and getValue(opt["Rx Signal"])) or 0
  
  local motorOn = opt.Motor ~= 0 and getSwitchValue(opt.Motor) == true
  local armOn   = opt.Arm   ~= 0 and getSwitchValue(opt.Arm)   == true
  local fm      = getFlightMode() or 0

  local texts = {
  motorOn and "MOTOR ON" or "MOTOR OFF",
  armOn and "ARMED" or "DISARMED",
  "FM" .. fm
  }

  local baseColor
  if rssVal == 0 then
    baseColor = WHITE
  else
    baseColor = PINK
  end

  local motorColor = motorOn and DARKRED or baseColor
  local armColor   = armOn   and DARKRED or baseColor

  lcd.drawText(z.x + 55, z.y + 8, texts[1], MIDSIZE + motorColor)
  lcd.drawText(z.x + 220, z.y + 8, texts[2], MIDSIZE + armColor)
  lcd.drawText(z.x + z.w - 170, z.y + (z.h - 90), texts[3], DBLSIZE + ((rssVal ~= 0) and PINK or WHITE))
  lcd.drawText(z.x + z.w - 10, z.y + 8, model.getInfo().name or "MODEL", RIGHT + MIDSIZE + ((rssVal ~= 0) and PINK or WHITE))

  if bm then
    lcd.drawBitmap(bm, z.x + 65, z.y + 46)
  end

  ---------------------------------------------------------------------------
  -- OPTIONS / TELEMTERY VALUES
  ---------------------------------------------------------------------------
  local rqtyVal = (opt["Rx Qty"] ~= 0 and getValue(opt["Rx Qty"])) or 0
  local tescVal = (opt["Tesc"] ~= 0 and getValue(opt["Tesc"])) or 0
  local cellsVal = (opt["Cells"] ~= 0 and getValue(opt["Cells"])) or 0
  local vbecVal = (opt["Vbec"] ~= 0 and getValue(opt["Vbec"])) or 0
  local currVal = (opt["Curr"] ~= 0 and getValue(opt["Curr"])) or 0
  local rpmVal  = (opt["Rpm"] ~= 0 and getValue(opt["Rpm"])) or 0
  local vbatVal  = (opt["Rx Batt"]  ~= 0 and getValue(opt["Rx Batt"]))  or 0
  local cellsVal  = (opt["Cells"]  ~= 0 and getValue(opt["Cells"]))  or 0
  
  lcd.drawText((z.x + (z.w / 8 * 1)), z.y + (z.h - 45), string.format("%ddB", rssVal), CENTER + ((rssVal ~= 0) and tlmColor or WHITE))
  lcd.drawText((z.x + (z.w / 8 * 1)), z.y + (z.h - 25), sourceLabel(opt["Rx Signal"], "1RSS"), CENTER + ((rssVal ~= 0) and tlmColor or WHITE))

  lcd.drawText((z.x + (z.w / 8 * 2)), z.y + (z.h - 45), string.format("%d%%", rqtyVal), CENTER + ((rssVal ~= 0) and tlmColor or WHITE))
  lcd.drawText((z.x + (z.w / 8 * 2)), z.y + (z.h - 25), sourceLabel(opt["Rx Qty"], "RQly"), CENTER + ((rssVal ~= 0) and tlmColor or WHITE))

  lcd.drawText((z.x + (z.w / 8 * 3)), z.y + (z.h - 45), string.format("%d°C", tescVal), CENTER + ((rssVal ~= 0) and tlmColor or WHITE))
  lcd.drawText((z.x + (z.w / 8 * 3)), z.y + (z.h - 25), sourceLabel(opt["Tesc"], "TESC"), CENTER + ((rssVal ~= 0) and tlmColor or WHITE))

  lcd.drawText((z.x + (z.w / 8 * 4)), z.y + (z.h - 45), string.format("%dS", cellsVal), CENTER + ((rssVal ~= 0) and tlmColor or WHITE))
  lcd.drawText((z.x + (z.w / 8 * 4)), z.y + (z.h - 25), sourceLabel(opt["Cells"], "CELLS"), CENTER + ((rssVal ~= 0) and tlmColor or WHITE))

  lcd.drawText((z.x + (z.w / 8 * 5)), z.y + (z.h - 45), string.format("%.1fV", vbecVal), CENTER + ((rssVal ~= 0) and tlmColor or WHITE))
  lcd.drawText((z.x + (z.w / 8 * 5)), z.y + (z.h - 25), sourceLabel(opt["Vbec"], "VBEC"), CENTER + ((rssVal ~= 0) and tlmColor or WHITE))

  lcd.drawText((z.x + (z.w / 8 * 6)), z.y + (z.h - 45), string.format("%dA", currVal), CENTER + ((rssVal ~= 0) and tlmColor or WHITE))
  lcd.drawText((z.x + (z.w / 8 * 6)), z.y + (z.h - 25), sourceLabel(opt["Curr"], "CURR"), CENTER + ((rssVal ~= 0) and tlmColor or WHITE))

  lcd.drawText(z.x + 25, z.y + 50, string.format("%d", rpmVal), DBLSIZE + LEFT + BOLD + ((rssVal ~= 0) and PINK or WHITE))

  ---------------------------------------------------------------------------
  -- TX TIME
  ---------------------------------------------------------------------------
  local dt = getDateTime()
  local months = { "Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec" }

  lcd.drawText((z.x + (z.w / 8 * 7)), z.y + (z.h - 45), string.format("%d %s", dt.day, months[dt.mon]), CENTER + ((rssVal ~= 0) and DARKRED or WHITE))
  lcd.drawText((z.x + (z.w / 8 * 7)), z.y + (z.h - 25), string.format("%02d:%02d", dt.hour, dt.min), CENTER + ((rssVal ~= 0) and DARKRED or WHITE))
  ---------------------------------------------------------------------------
  -- TIMER
  ---------------------------------------------------------------------------
  
  local timer = model.getTimer(0)
  local timeLeft = timer.value or 0
  
  lcd.drawText(z.x + z.w - 10, z.y + (z.h - 90), string.format("%02d:%02d", math.floor(timeLeft / 60), timeLeft % 60), RIGHT + DBLSIZE + ((rssVal ~= 0) and YELLOW or WHITE))

  ---------------------------------------------------------------------------
  -- TX VOLTAGE
  ---------------------------------------------------------------------------
  local txV = getValue("tx-voltage") or 0

  local txvColor
  if txV > 7.5 then
    txvColor = GREEN
  elseif txV > 6.8 then
    txvColor = YELLOW
  else 
    txvColor = DARKRED
  end

  lcd.drawText(z.x + z.w - 10, z.y + (z.h - 130), string.format("%.1fV", txV), RIGHT + DBLSIZE + txvColor)

  -------------------------------------------------------------------------
  -- RX BATTERY
  -------------------------------------------------------------------------

  local detectedCells
  if cellsVal and cellsVal >= 3 and cellsVal <= 12 then
    detectedCells = cellsVal
  end

  local cells = detectedCells or 1
  local vPerCell = (cells > 0 and vbatVal > 0) and (vbatVal / cells) or 0

  -- VBAT Voltage → Percentage
  local vMin = 3.3
  local vMax = 4.2

  local vPercent = (vPerCell - vMin) / (vMax - vMin)
  vPercent = math.max(0, math.min(1, vPercent))

  -- VBAT Color + flash logic
  local vColor = GREEN
  local flash = false

  if vPercent <= 0.25 then
    vColor = RED
    flash = true
  elseif vPercent <= 0.50 then
    vColor = YELLOW
  end

  if flash and (getTime() % 20 < 10) then
    vColor = BLACK
  end

  -- DRAW BATTERY ICON
  local battW = 150
  local battH = 45
  local battX = z.x + 30
  local battY = z.y + (z.h - 95)

  drawBatteryIcon(battX,battY,battW,battH,vPercent,vColor)

  local textX = battX + battW / 2
  local textY = battY + 2

  lcd.drawText(textX, textY, string.format("%.2fV", vbatVal),CENTER + WHITE + BOLD)

  if detectedCells and vPerCell > 0 then
    lcd.drawText(textX, textY + 14, string.format("%.2fV / %dS", vPerCell, detectedCells), CENTER + WHITE)
  end


end
---------------------------------------------------------------------------

return {
  name = name,
  create = create,
  refresh = refresh,
  update = update,
  options = options
}
